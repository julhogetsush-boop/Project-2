# PMSM air-gap finite-difference reproduction

This small Python project independently reconstructs the **physical air-gap benchmark** in `PMSM_Report(1).pdf`. It is **not the original Team 13 repository**, a PINN implementation, a real-motor experiment, or a reconstruction of Team 7's mixed-boundary solver. The source PDF is not bundled. The model follows report equations (3), (6), (7), (13), (18) and (20), and comparison values appear in Tables 4–6.

## Quick start

Use Python 3.10 or newer. Open a terminal in this folder:

```sh
python -m pip install -r requirements.txt
python run_all.py
```

On Windows, if `python` is unavailable, use `py` instead. For optional tests:

```sh
python -m unittest -v
```

The default run performs direct-solver refinement at n = 16, 32, 64, 128, 256 and CG tolerance sweeps at n = 64 and 128. To omit the added n = 256 solve:

```sh
python run_all.py --skip-256
```

## Outputs

- `results/cg_tolerance.csv`: requested tolerance, actual relative residual, iteration count, total discrete L2 error against the analytical solution, algebraic error against the direct solve, residual-based bound, and whether the bound is at most 0.001 times the reference discretisation error.
- `results/refinement.csv`: dimensionless mesh size, direct-solver error, residual, algebraic bound and pairwise convergence order.
- `results/results.json`: the full data, parameters, Python/NumPy/SciPy versions, platform, source SHA256 and Git metadata.
- `results/summary.txt`: concise actual run results suitable for checking and transcribing.
- `sample_results/`: output from the delivered script's verification run. These are reference outputs from the preparation environment, not a claim that the student ran the code.

Each run overwrites `results/`. Copy outputs elsewhere if you want to retain several runs. Timings and last-digit residuals depend on numerical libraries and hardware. The runtime used to prepare the sample outputs was NumPy 2.3.5 and SciPy 1.17.0. This package uses a compatible dependency range, not a complete binary environment lock.

## Model and discretisation

The mapped domain is a unit rectangle with periodic x and prescribed radial Dirichlet boundaries. The PDE is

`-kappa^2 * u_xx - u_yy = 0`.

Parameters: a = 0.050 m, b = 0.051 m, p = 4, m = 1, qd = 0.25, qq = 0.50. Define beta = p log(b/a), kappa = beta/(2 pi), c0 = m/cosh(beta).

- At y=0: g0(x) = m cos(2 pi x).
- At y=1: g1(x) = (c0+qd) cos(2 pi x) + qq sin(2 pi x).
- h = 1/n is **dimensionless**, not metres.
- Unknowns are n periodic angular nodes on n-1 interior radial levels, stored with x varying fastest.
- The sparse five-point matrix is `K = (kappa^2 I kron C + T kron I)/h^2`.
- The first and last radial rows receive `+g0/h^2` and `+g1/h^2` in the RHS.

The exact continuous solution is built from S(y) = sinh(beta y)/sinh(beta) and P(y) = S(1-y), as in the report. The error norm is `h * ||u_numeric - u_exact||_2`, including interior nodes only. qd and qq are dimensionless boundary amplitudes, **not winding currents**.

The direct solve supplies an approximation to the exact discrete solution. Its residual-based algebraic bound is separately checked to be far below the measured direct-versus-continuous error. The reported discretisation error therefore uses this independently checked direct solve as reference.

CG starts at zero, uses absolute tolerance zero, and is accepted only if it returns convergence. The explicit smallest eigenvalue is `lambda_min = 4/h^2 sin(pi/(2n))^2`. The algebraic bound is `h ||b-Ku||_2/lambda_min`; the relative residual is `||b-Ku||_2/||b||_2`. These are different quantities. A bound may be conservative.

## How to use the reproduction form

1. Choose an explicit target, for example: "n=128, CG rtol=1e-3, discrete L2 potential error approximately 9.353e-8".
2. Upload the **source files**, README and requirements to your own GitHub repository. Keep this folder as the repository root if you want automatic Git detection.
3. Commit the source. Obtain the actual commit ID from GitHub or `git rev-parse HEAD`. Do not reuse another team's commit or invent a hash.
4. Run that committed version and inspect `results/summary.txt`. A downloaded ZIP has no Git metadata, so a null commit in the output is normal: manually identify the exact source commit you downloaded.
5. In "Results from your run", enter the actual numbers you obtained and state whether they agree with the target. Label the code as a reconstruction. Do not say you ran the original report repository.

`git.dirty=true` means the working tree contains uncommitted changes. In that case a commit ID alone does not fully identify the executed source. Commit the changes and rerun. Generated `results/` and Python caches are ignored. The script rejects a parent repository's hash to avoid recording an unrelated workspace commit.

## Tutorial interpretation

- Tolerance challenge: compare n=128 at 1e-2 and 1e-3, and list both actual residuals as well as errors. "Loosest tested" refers only to the tested tolerance list, not to every possible tolerance.
- Added-mesh challenge: n=256 is newly computed by this package. Compare it with n=128 using `log2(E128/E256)`. The new run remains a reconstructed-model test until integrated into the team's actual project.
- The available meshes do not locate a floating-point round-off floor. A decreasing error does not certify how far further refinement will remain useful.
- The 127-iteration plateau is specific to this single-angular-harmonic benchmark. Do not generalise it to arbitrary forcing or geometry.
- This script does not evaluate torque or train PINNs. It does not test Neumann/Robin boundary closures.

## Authorship and reproducibility disclosure

This code and its documentation were prepared with AI assistance on 3 November 2026, independently from the equations and parameters of the supplied report. It was executed and checked in a preparation environment. Students should review the equations, run the code themselves, retain actual outputs, and record assistance and their own changes according to the course's AI Transparency Log and individual-contribution requirements. No student contribution history is asserted.
