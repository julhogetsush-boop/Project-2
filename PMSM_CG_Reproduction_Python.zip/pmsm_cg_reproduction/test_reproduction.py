"""Run with python -m unittest -v."""
import unittest
import numpy as np
from run_all import problem, solve_grid


class ReproductionTests(unittest.TestCase):
    def test_boundary_rhs(self):
        n=16
        A,b,_,h,_=problem(n)
        beta=4*np.log(0.051/0.050)
        # Independent samples of the first/last boundary rows.
        i=3
        angle=2*np.pi*i/n
        self.assertAlmostEqual(b[i],np.cos(angle)/h**2,places=11)
        expected=((1/np.cosh(beta)+0.25)*np.cos(angle)+0.5*np.sin(angle))/h**2
        self.assertAlmostEqual(b[(n-2)*n+i],expected,places=11)
        self.assertEqual(b[n+i],0.0)
        self.assertEqual(A[0,n-1],A[0,1])
        self.assertEqual((A-A.T).nnz,0)

    def test_reference_and_order(self):
        coarse,_=solve_grid(32,[])
        fine,_=solve_grid(64,[])
        order=np.log2(coarse['discrete_L2_error']/fine['discrete_L2_error'])
        self.assertTrue(1.99<order<2.01)
        self.assertTrue(np.isclose(fine['discrete_L2_error'],3.740e-7,rtol=0.001))

    def test_tolerance_improvement(self):
        _,rows=solve_grid(128,[1e-2,1e-3])
        self.assertFalse(rows[0]['meets_1e_minus_3_target'])
        self.assertTrue(rows[1]['meets_1e_minus_3_target'])
        self.assertLess(rows[1]['discrete_L2_error'],rows[0]['discrete_L2_error']/1e4)


if __name__=='__main__':
    unittest.main()
