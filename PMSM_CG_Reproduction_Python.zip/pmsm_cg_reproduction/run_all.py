"""Reconstructed PMSM report benchmark, not the original team repository.

Run: python run_all.py
Outputs CSV, JSON and a plain-text reproduction summary in results/.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import platform
import subprocess
import sys
import time
import numpy as np
import scipy
from scipy.sparse import diags, eye, kron
from scipy.sparse.linalg import cg, spsolve

ROOT = Path(__file__).resolve().parent
PARAMS = dict(a=0.05, b=0.051, pole_pairs=4, m=1.0, qd=0.25, qq=0.5)


def problem(n):
    """x varies fastest; n periodic nodes, n-1 radial interior levels."""
    if n < 3:
        raise ValueError('n must be at least 3')
    h = 1.0 / n
    beta = PARAMS['pole_pairs'] * np.log(PARAMS['b']/PARAMS['a'])
    kappa = beta / (2*np.pi)
    x = np.arange(n)*h
    y = np.arange(1, n)*h
    cyclic = diags([-np.ones(n-1), 2*np.ones(n), -np.ones(n-1)], [-1,0,1], format='lil')
    cyclic[0,-1] = cyclic[-1,0] = -1.0
    radial = diags([-np.ones(n-2),2*np.ones(n-1),-np.ones(n-2)],[-1,0,1],format='csr')
    matrix = (kappa**2*kron(eye(n-1),cyclic.tocsr()) + kron(radial,eye(n))).tocsr()/h**2
    c0 = PARAMS['m']/np.cosh(beta)
    g0 = PARAMS['m']*np.cos(2*np.pi*x)
    g1 = (c0+PARAMS['qd'])*np.cos(2*np.pi*x)+PARAMS['qq']*np.sin(2*np.pi*x)
    rhs = np.zeros((n-1,n))
    rhs[0] += g0/h**2
    rhs[-1] += g1/h**2
    s = np.sinh(beta*y)/np.sinh(beta)
    p = np.sinh(beta*(1-y))/np.sinh(beta)
    exact = (PARAMS['m']*p[:,None]+(c0+PARAMS['qd'])*s[:,None])*np.cos(2*np.pi*x)[None,:] + PARAMS['qq']*s[:,None]*np.sin(2*np.pi*x)[None,:]
    lam_min = 4/h**2*np.sin(np.pi/(2*n))**2
    return matrix,rhs.ravel(),exact.ravel(),h,lam_min


def norm_h(v,h):
    return float(h*np.linalg.norm(v))


def solve_grid(n, tolerances):
    A,b,exact,h,lam = problem(n)
    direct = spsolve(A,b)
    disc = norm_h(direct-exact,h)
    direct_res = b-A@direct
    bound = norm_h(direct_res,h)/lam
    # Structural and independent consistency checks, not just a small residual.
    assert A.shape == (n*(n-1),)*2
    assert A.nnz == 5*n*(n-1)-2*n
    assert (A-A.T).nnz == 0
    assert disc > 0 and bound < 1e-3*disc
    row = dict(n=n,h=h,discrete_L2_error=disc,relative_residual=float(np.linalg.norm(direct_res)/np.linalg.norm(b)),algebraic_error_bound=bound)
    sweeps=[]
    for tol in tolerances:
        iterations=[0]
        def count(_):
            iterations[0]+=1
        start=time.perf_counter()
        u,info=cg(A,b,x0=np.zeros_like(b),rtol=tol,atol=0.0,maxiter=10*n*n,callback=count)
        elapsed=time.perf_counter()-start
        if info != 0:
            raise RuntimeError(f'CG failed: n={n}, rtol={tol}, info={info}')
        residual=b-A@u
        alg_bound=norm_h(residual,h)/lam
        sweeps.append(dict(n=n,h=h,rtol=tol,iterations=iterations[0],relative_residual=float(np.linalg.norm(residual)/np.linalg.norm(b)),raw_residual_L2=float(np.linalg.norm(residual)),discrete_L2_error=norm_h(u-exact,h),algebraic_error_vs_direct=norm_h(u-direct,h),discretisation_error_reference=disc,algebraic_error_bound=alg_bound,bound_over_discretisation=alg_bound/disc,meets_1e_minus_3_target=bool(alg_bound<=1e-3*disc),elapsed_seconds=elapsed))
    return row,sweeps


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def git_info():
    # Refuse an unrelated ancestor repository's commit.
    try:
        top=subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=ROOT,text=True,stderr=subprocess.DEVNULL).strip()
        if Path(top).resolve()!=ROOT:
            return dict(commit=None,dirty=None,note='No Git repository rooted at this project folder.')
        commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True,stderr=subprocess.DEVNULL).strip()
        dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip())
        return dict(commit=commit,dirty=dirty)
    except (subprocess.CalledProcessError,FileNotFoundError):
        return dict(commit=None,dirty=None,note='Commit unavailable. Commit the source before reproducing.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-256',action='store_true',help='Only refine through n=128')
    args=parser.parse_args()
    out=ROOT/'results'
    out.mkdir(exist_ok=True)
    grids=[16,32,64,128]+([] if args.skip_256 else [256])
    refinement=[]
    tolerance_rows=[]
    for n in grids:
        tolerances=[1e-2,1e-3,1e-4,1e-6,1e-8,1e-10] if n in (64,128) else []
        row,sweeps=solve_grid(n,tolerances)
        row['order_vs_previous']=None if not refinement else float(np.log2(refinement[-1]['discrete_L2_error']/row['discrete_L2_error']))
        refinement.append(row)
        tolerance_rows.extend(sweeps)
        print(f'n={n:3d}, h={row["h"]:.8g}, L2h error={row["discrete_L2_error"]:.12e}, order={row["order_vs_previous"]}')
    fit=float(np.polyfit(np.log([r['h'] for r in refinement]),np.log([r['discrete_L2_error'] for r in refinement]),1)[0])
    assert 1.98 < fit < 2.02, 'Unexpected convergence order'
    n128=[r for r in tolerance_rows if r['n']==128]
    # Broad numerical regression checks avoid pretending bitwise portability.
    assert np.isclose(n128[0]['discrete_L2_error'],8.940e-2,rtol=5e-3)
    assert np.isclose(n128[1]['discrete_L2_error'],9.353e-8,rtol=5e-3)
    assert n128[1]['meets_1e_minus_3_target']
    write_csv(out/'cg_tolerance.csv',tolerance_rows)
    write_csv(out/'refinement.csv',refinement)
    metadata=dict(provenance='Independent reconstruction of PMSM_Report(1).pdf equations (3), (6), (7), (13), (18), (20). Not the original team repository.',python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),parameters=PARAMS,git=git_info(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fit_order=fit)
    (out/'results.json').write_text(json.dumps(dict(metadata=metadata,refinement=refinement,cg_tolerance=tolerance_rows),indent=2),encoding='utf-8')
    lines=['PMSM reconstructed benchmark: actual run output', 'Discrete L2 norm = h * Euclidean norm over interior nodes.', 'h is dimensionless in the mapped unit rectangle.', f'Git commit: {metadata["git"]["commit"]}', f'Git dirty: {metadata["git"]["dirty"]}', f'Fitted refinement order: {fit:.8f}', '']
    for r in n128:
        lines.append(f'rtol={r["rtol"]:.0e}: iterations={r["iterations"]}, residual={r["relative_residual"]:.12e}, L2h error={r["discrete_L2_error"]:.12e}, algebraic bound={r["algebraic_error_bound"]:.12e}, ratio={r["bound_over_discretisation"]:.12e}, passes={r["meets_1e_minus_3_target"]}')
    passing=[r for r in n128 if r['meets_1e_minus_3_target']]
    lines.append(f'Loosest TESTED qualifying tolerance: {max(r["rtol"] for r in passing):.0e}')
    lines.append('No round-off floor can be located from these few meshes alone. See refinement.csv for observed behaviour.')
    (out/'summary.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'+'\n'.join(lines))
    print(f'\nSaved actual outputs to {out}')


if __name__=='__main__':
    main()
